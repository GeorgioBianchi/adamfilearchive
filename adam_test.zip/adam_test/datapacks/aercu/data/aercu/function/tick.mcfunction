title @a[gamemode=creative] actionbar ["",{"color":"yellow","text":"[<YOU ARE IN DEVELOPER MODE>]"}]
title @a[gamemode=adventure] actionbar ["",{"color":"light_purple","text":"[<YOU ARE IN INTERACTION MODE>]"}]
